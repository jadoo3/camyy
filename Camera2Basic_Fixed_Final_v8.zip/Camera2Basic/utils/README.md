Do not modify code under this folder outside of `CameraUtils`, it is copied
automatically by `.github/scripts/copy_utils.sh`.